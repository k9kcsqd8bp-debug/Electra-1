Evaluation metrics and prediction CSV files are generated here by the app.
